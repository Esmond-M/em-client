<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package em-client
 */

get_header();
?>

	<main id="primary" class="site-main em-single-content">

		<?php
		while ( have_posts() ) :
			the_post();

           ?>
		    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				<?php 
				if( get_the_post_thumbnail_url() ){

				?>
				<div class="featured-img" style="background-image: url('<?php echo get_the_post_thumbnail_url();?>');"> 
				</div>
				<?php
				}

				else{
				?>	
				<div class="featured-img" style="background-image: url('<?php echo get_stylesheet_directory_uri() . "/assets/img/blog-placeholder.jpg"?>');"></div>
				<?php
				}
		
				?>
				<header class="entry-header">
					<?php
					if ( is_singular() ) :
						the_title( '<h1 class="entry-title">', '</h1>' );
					else :
						the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
					endif;

					if ( 'post' === get_post_type() ) :
						?>
						<div class="entry-meta">
							<?php
							EmClient_Template_Tags::posted_on();
							EmClient_Template_Tags::posted_by();
							?>
						</div><!-- .entry-meta -->
					<?php endif; ?>
				</header><!-- .entry-header -->
				<div class="entry-content">
					<?php
					the_content();

					wp_link_pages(
						array(
							'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'em-client' ),
							'after'  => '</div>',
						)
					);
					?>
				</div><!-- .entry-content -->

				<footer class="entry-footer">
					<?php EmClient_Template_Tags::entry_footer(); ?>
				</footer><!-- .entry-footer -->
		</article><!-- #post-<?php the_ID(); ?> -->
		   <?php

			the_post_navigation(
				array(
					'prev_text' => '<span class="nav-subtitle">' . esc_html__( 'Previous:', 'em-client' ) . '</span> <span class="nav-title">%title</span>',
					'next_text' => '<span class="nav-subtitle">' . esc_html__( 'Next:', 'em-client' ) . '</span> <span class="nav-title">%title</span>',
				)
			);

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		endwhile; // End of the loop.
		?>

	</main><!-- #main -->

<?php
get_footer();
