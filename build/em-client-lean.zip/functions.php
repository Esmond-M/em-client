<?php

/**
 * Theme functions and definitions.
 *
 * Sets up the theme and provides some helper functions
 *
 * When using a child theme (see http://codex.wordpress.org/Theme_Development
 * and http://codex.wordpress.org/Child_Themes), you can override certain
 * functions (those wrapped in a function_exists() call) by defining them first
 * in your child theme's functions.php file. The child theme's functions.php
 * file is included before the parent theme's file, so the child theme
 * functions would be used.
 *
 *
 * For more information on hooks, actions, and filters,
 * see http://codex.wordpress.org/Plugin_API
 *
 * @package emclientWP WordPress theme
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * emclientWP theme class
 */
final class EMCLIENT_Theme_Class {

    /**
     * Main Theme Class Constructor
     *
     * @since   1.0.0
     */
    public function __construct() {
        // Load framework classes.
        add_action( 'after_setup_theme', array( 'EMCLIENT_Theme_Class', 'classes' ), 4 );
        // Setup theme => add_theme_support, register_nav_menus, load_theme_textdomain, etc.
        add_action( 'after_setup_theme', array( 'EMCLIENT_Theme_Class', 'theme_setup' ), 10 );
        // register sidebar widget areas.
        add_action( 'widgets_init', array( 'EMCLIENT_Theme_Class', 'register_sidebars' ) );

        /** Admin only actions */
        if ( is_admin() ) {
            /** Non Admin actions */
        } else {
            // Load theme js.
            add_action( 'wp_enqueue_scripts',  [$this, 'theme_js' ]  );
            // Load theme CSS.
            add_action( 'wp_enqueue_scripts',  [$this, 'theme_css' ] );
            // Add a pingback url auto-discovery header for singularly identifiable articles.
            add_action( 'wp_head',  [$this, 'pingback_header' ] , 1 );
            // Add an X-UA-Compatible header removed (IE EOL).
            add_filter( 'emclient_enqueue_generated_files', '__return_false' );
        }
    }

    /**
     * Static replacements for theme constants
     */
    public static function theme_dir() {
        return get_template_directory();
    }
    public static function theme_uri() {
        return get_template_directory_uri();
    }
    public static function theme_version() {
        return '3.6.0';
    }
    public static function lib_dir() {
        return self::theme_dir() . '/lib/';
    }
    public static function js_dir_uri() {
        return self::theme_uri() . '/assets/js/';
    }
    public static function css_dir_uri() {
        return self::theme_uri() . '/assets/css/';
    }
    public static function inc_dir() {
        return self::theme_dir() . '/inc/';
    }

    /**
     * Load theme classes
     *
     * @since   1.0.0
     */
    public static function classes() {
        $dir_include = self::inc_dir();
        require $dir_include . 'class-nav-walker-mobile.php';
        require $dir_include . 'class-nav-walker-desktop.php';
    }

    /**
     * Theme Setup
     *
     * @since   1.0.0
     */
    public static function theme_setup() {
        $dir_include = self::inc_dir();
        // Load text domain.
        load_theme_textdomain( 'em-client', self::theme_dir() . '/languages' );

        // Get globals.
        global $content_width;

        // Set content width based on theme's default design.
        if ( ! isset( $content_width ) ) {
            $content_width = 1200;
        }

        // Register navigation menus.
        register_nav_menus(
            array(
                'primary_menu' => esc_html__( 'Primary', 'em-client' ),
                'footer_menu' => esc_html__( 'Footer', 'em-client' ),
                'mobile_menu' => esc_html__( 'Mobile (optional)', 'em-client' ),
            )
        );

        // Enable support for Post Formats.
        add_theme_support( 'post-formats', array( 'video', 'gallery', 'audio', 'quote', 'link' ) );

        // Enable support for <title> tag.
        add_theme_support( 'title-tag' );

        // Add default posts and comments RSS feed links to head.
        add_theme_support( 'automatic-feed-links' );

        // Enable support for Post Thumbnails on posts and pages.
        add_theme_support( 'post-thumbnails' );

        /**
         * Enable support for site logo
         */
        add_theme_support(
            'custom-logo',
            apply_filters(
                'emclient_custom_logo_args',
                array(
                    'height'      => 45,
                    'width'       => 164,
                    'flex-height' => true,
                    'flex-width'  => true,
                )
            )
        );
        // Set up the WordPress core custom background feature.
        add_theme_support(
            'custom-background',
            apply_filters(
                'emclient_custom_background_args',
                array(
                    'default-color' => 'ffffff',
                    'default-image' => '',
                )
            )
        );
        /*
         * Switch default core markup for search form, comment form, comments, galleries, captions and widgets
         * to output valid HTML5.
         */
        add_theme_support(
            'html5',
            array(
                'comment-form',
                'comment-list',
                'gallery',
                'caption',
                'style',
                'script',
                'widgets',
            )
        );

        // Declare support for selective refreshing of widgets.
        add_theme_support( 'customize-selective-refresh-widgets' );

        /**
         * Custom template tags for this theme.
         */
        require $dir_include . 'template-tags.php';

        /**
         * Customizer additions.
         */
        require $dir_include . 'customizer.php';

        /**
         * Load Jetpack compatibility file.
         */
        if ( defined( 'JETPACK__VERSION' ) ) {
            require $dir_include . 'jetpack.php';
        }
    }

    /**
     * Adds the meta tag to the site header
     *
     * @since 1.1.0
     */
    public static function pingback_header() {

        if ( is_singular() && pings_open() ) {
            printf( '<link rel="pingback" href="%s">' . "\n", esc_url( get_bloginfo( 'pingback_url' ) ) );
        }

    }

    /**
     * Load front-end scripts
     *
     * @since   1.0.0
     */
    public static function theme_css() {

        // Define dir.
        $dir           =  self::css_dir_uri();
        $theme_version = self::theme_version();
        // Enqueue Main style.
        wp_enqueue_style( 'emclient-min', get_stylesheet_directory_uri() . '/assets/css/style.min.css', array(), $theme_version );
        wp_enqueue_style( 'gfont-css', get_stylesheet_directory_uri() . '/assets/css/g-fonts.css', array(), $theme_version );
        wp_style_add_data( 'emclient-min', 'rtl', 'replace' );
    }

    /**
     * Returns all js needed for the front-end
     *
     * @since 1.0.0
     */
    public static function theme_js() {

        // Get js directory uri.
        $dir = self::js_dir_uri();

        // Get current theme version.
        $theme_version = self::theme_version();

        // Comment reply.
        if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
            wp_enqueue_script( 'comment-reply' );
        }

        /**
         * Load Theme Scripts.
         */

        wp_enqueue_script( 'emclient-general', $dir . 'general.js', array(), $theme_version, true );
    }


    /**
     * Registers sidebars
     *
     * @since   1.0.0
     */
    public static function register_sidebars() {

        $heading = get_theme_mod( 'emclient_sidebar_widget_heading_tag', 'h4' );
        $heading = apply_filters( 'emclient_sidebar_widget_heading_tag', $heading );

        $foo_heading = get_theme_mod( 'emclient_footer_widget_heading_tag', 'h4' );
        $foo_heading = apply_filters( 'emclient_footer_widget_heading_tag', $foo_heading );

        // Default Sidebar.
        register_sidebar(
            array(
                'name'          => esc_html__( 'Default Sidebar', 'em-client' ),
                'id'            => 'sidebar',
                'description'   => esc_html__( 'Widgets in this area will be displayed in the left or right sidebar area if you choose the Left or Right Sidebar layout.', 'em-client' ),
                'before_widget' => '<div id="%1$s" class="sidebar-box %2$s clr">',
                'after_widget'  => '</div>',
                'before_title'  => '<' . $heading . ' class="widget-title">',
                'after_title'   => '</' . $heading . '>',
            )
        );

        // Left Sidebar.
        register_sidebar(
            array(
                'name'          => esc_html__( 'Left Sidebar', 'em-client' ),
                'id'            => 'sidebar-2',
                'description'   => esc_html__( 'Widgets in this area are used in the left sidebar region if you use the Both Sidebars layout.', 'em-client' ),
                'before_widget' => '<div id="%1$s" class="sidebar-box %2$s clr">',
                'after_widget'  => '</div>',
                'before_title'  => '<' . $heading . ' class="widget-title">',
                'after_title'   => '</' . $heading . '>',
            )
        );

        // Search Results Sidebar.
        if ( get_theme_mod( 'emclient_search_custom_sidebar', true ) ) {
            register_sidebar(
                array(
                    'name'          => esc_html__( 'Search Results Sidebar', 'em-client' ),
                    'id'            => 'search_sidebar',
                    'description'   => esc_html__( 'Widgets in this area are used in the search result page.', 'em-client' ),
                    'before_widget' => '<div id="%1$s" class="sidebar-box %2$s clr">',
                    'after_widget'  => '</div>',
                    'before_title'  => '<' . $heading . ' class="widget-title">',
                    'after_title'   => '</' . $heading . '>',
                )
            );
        }

        // Footer 1.
        register_sidebar(
            array(
                'name'          => esc_html__( 'Footer 1', 'em-client' ),
                'id'            => 'footer-one',
                'description'   => esc_html__( 'Widgets in this area are used in the first footer region.', 'em-client' ),
                'before_widget' => '<div id="%1$s" class="footer-widget %2$s clr">',
                'after_widget'  => '</div>',
                'before_title'  => '<' . $foo_heading . ' class="widget-title">',
                'after_title'   => '</' . $foo_heading . '>',
            )
        );

        // Footer 2.
        register_sidebar(
            array(
                'name'          => esc_html__( 'Footer 2', 'em-client' ),
                'id'            => 'footer-two',
                'description'   => esc_html__( 'Widgets in this area are used in the second footer region.', 'em-client' ),
                'before_widget' => '<div id="%1$s" class="footer-widget %2$s clr">',
                'after_widget'  => '</div>',
                'before_title'  => '<' . $foo_heading . ' class="widget-title">',
                'after_title'   => '</' . $foo_heading . '>',
            )
        );
    }

    /**
     * Wrap a string with a character (default: double quotes)
     */
    public static function em_client_str_wrap_global($string = '', $char = '"')
    {
        return str_pad($string, strlen($string) + 2, $char, STR_PAD_BOTH);
    }
}

new EMCLIENT_Theme_Class();