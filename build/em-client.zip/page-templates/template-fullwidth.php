<?php
/*
Template Name: Fullwidth Page
*/
get_header();
?>

<div id="primary" class="content-area em-fullwidth">
    <main id="main" class="site-main">
        <?php
        while ( have_posts() ) : the_post();
            get_template_part( 'template-parts/content', 'page' );
        endwhile;
        ?>
    </main>
</div>

<?php get_footer(); ?>