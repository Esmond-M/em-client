# em-client
 
# [EM Cleint](https://github.com/Esmond-M/em-client)

* [Features](#features)
    + [Theme Files and Functionality](#theme-files-and-functionality)

Simple bolierplate WordPress theme.

Project: [https://github.com/Esmond-M/em-client](https://github.com/Esmond-M/em-client)<br>
Author: [esmondmccain.com](https://esmondmccain.com/)

## Getting Started with Esmond Theme

Download the latest version from [https://github.com/Esmond-M/esmond-theme](https://github.com/Esmond-M/esmond-theme/archive/master.zip)

## Features

### Theme Files and Functionality
* Custom frontpage template
* Templates to host react projects 
* Two custom post types
* Several custom post fields
* Custom post type items will be added to frontpage